
import java.awt.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.SwingConstants;

public class PegarPalavra {
    
    public PegarPalavra(){
        iniciarJanela();
    }

    
    //Encapsulamento
    private String palavra;
    
    public void setPalavra(String palavra){
        this.palavra = palavra;
    }
    
    public String getPalavra(){
        return palavra;
    }

    
    public void iniciarJanela(){
        
        JPanel painel = new JPanel((new BorderLayout(0, 0)));
        JFrame tela = new JFrame();
        
        tela.setSize(400, 200);
        tela.setLocationRelativeTo(null);
        tela.setResizable(false);
        tela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        painel.setBackground(Color.decode("#b3d5ff"));

        
        JLabel txt = new JLabel("(Sem caractere) Digite a palavra: ", SwingConstants.CENTER);
        txt.setSize(400, 50);
        txt.setFont(new Font("Roboto", 1, 16));
        txt.setForeground(Color.decode("#303030"));
        tela.add(txt);

        JTextField palavra = new JTextField();
        palavra.setBounds(23, 50, 340, 40);
        palavra.setBorder(null);
        palavra.setBackground(Color.decode("#FFFFFF"));
        palavra.setFont(new Font("Roboto", 1, 16));
        tela.add(palavra);

        JButton enviar = new JButton("Jogar");
        enviar.setBounds(182, 100, 180, 40);
        enviar.setBorder(null);
        enviar.setBackground(Color.decode("#FFFFFF"));
        enviar.setFont(new Font("Roboto", 1, 14));
        
        BotaoIniciar event = new BotaoIniciar(palavra, tela, painel);

        enviar.addActionListener(event);
        tela.add(enviar);
        
        tela.add(painel);
        tela.setVisible(true);
        
    }
    
}
