
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class BotaoIniciar implements ActionListener {

    JTextField palavra;
    JFrame tela;
    JPanel painel;

    static String dis = "";
    static int derrotas = 1;
    static int vitorias = 0;
    static String stringImg;

    char[] caracteres; 
    char[] espacos;
    
    ImageIcon v1 = new ImageIcon(getClass().getResource("IMG/V1.png"));
    ImageIcon v2 = new ImageIcon(getClass().getResource("IMG/V2.png"));
    ImageIcon v3 = new ImageIcon(getClass().getResource("IMG/V3.png"));
    ImageIcon v4 = new ImageIcon(getClass().getResource("IMG/V4.png"));
    ImageIcon v5 = new ImageIcon(getClass().getResource("IMG/V5.png"));

    final JLabel img = new JLabel(v1);

    public BotaoIniciar(JTextField palavra, JFrame tela, JPanel painel){
        this.palavra = palavra;
        this.tela = tela;
        this.painel = painel;
    }

    public void verificarVitoria(){
        for(int i = 0; i < espacos.length; i++){
            if(!new String(espacos).contains("_")){
                JOptionPane.showMessageDialog(null, "Fim de jogo! Você venceu.");
                System.exit(0);
            }
            else {
                continue;
            }
        }
    }

    public void verificarDerrota(){
        for(int i = 1; i <= derrotas; i++){
            img.setIcon(new ImageIcon(getClass().getResource("IMG/V" + i + ".png")));
        }
        if(derrotas == 5) {
            JOptionPane.showMessageDialog(null, "Fim de jogo! Você perdeu.");
            System.exit(0);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        String text = palavra.getText().toUpperCase();

        if(!text.isEmpty()){

            caracteres = new char[text.length()];
            espacos = new char[text.length()];

            JFrame jogo = new JFrame();

            
            tela.dispose();
            jogo.setSize(680, 800);
            jogo.setLocationRelativeTo(null);
            jogo.setResizable(false);
            jogo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            for(int i = 0; i < caracteres.length; i++){
                if(text.charAt(i) == ' '){
                    caracteres[i] = '⎵';
                    espacos[i] = '⎵';
                }
                else {
                    caracteres[i] = text.charAt(i);
                    espacos[i] = '_';
                }
            }

            for(int i = 0; i < caracteres.length; i++){
                dis += espacos[i] + " ";
            }


            final JLabel display = new JLabel(dis, SwingConstants.CENTER); 
            display.setSize(680, 950);
            display.setFont(new Font("Roboto", 1, 26));
            jogo.add(display);

            img.setBounds(0, 0, 500, 500);
            jogo.add(img);

            //Parte 1 do teclado

            int altura1 = 550;
            int altura2 = 600;
            int altura3 = 650;

            JButton q = new JButton("Q"); //Botão Q do "teclado"
            q.setBounds(100, altura1, 40, 45);
            q.setBorder(null);
            q.setBackground(Color.decode("#FFFFFF"));
            q.setFont(new Font("Roboto", 1, 14));
            jogo.add(q);

            q.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    verificarVitoria();
                    dis = "";
                    if(new String(caracteres).contains("Q")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'Q'){
                                espacos[i] = 'Q';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                    } else {
                        derrotas = derrotas + 1;
                        System.out.println("Letras incorretas: " + derrotas);
                        verificarDerrota();
                    }
                }
            });

            JButton w = new JButton("W");
            w.setBounds(145, altura1, 40, 45);
            w.setBorder(null);
            w.setBackground(Color.decode("#FFFFFF"));
            w.setFont(new Font("Roboto", 1, 14));
            jogo.add(w);

            w.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    verificarVitoria();
                    dis = "";
                    if(new String(caracteres).contains("W")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'W'){
                                espacos[i] = 'W';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });

            JButton e1 = new JButton("E");
            e1.setBounds(190, altura1, 40, 45);
            e1.setBorder(null);
            e1.setBackground(Color.decode("#FFFFFF"));
            e1.setFont(new Font("Roboto", 1, 14));
            jogo.add(e1);

            e1.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    verificarVitoria();
                    dis = "";
                    if(new String(caracteres).contains("E")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'E'){
                                espacos[i] = 'E';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                        verificarVitoria();
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });

            JButton r = new JButton("R");
            r.setBounds(235, altura1, 40, 45);
            r.setBorder(null);
            r.setBackground(Color.decode("#FFFFFF"));
            r.setFont(new Font("Roboto", 1, 14));
            jogo.add(r);

            r.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    dis = "";
                    if(new String(caracteres).contains("R")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'R'){
                                espacos[i] = 'R';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                        verificarVitoria();
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });

            JButton t = new JButton("T");
            t.setBounds(280, altura1, 40, 45);
            t.setBorder(null);
            t.setBackground(Color.decode("#FFFFFF"));
            t.setFont(new Font("Roboto", 1, 14));
            jogo.add(t);

            t.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    dis = "";
                    if(new String(caracteres).contains("T")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'T'){
                                espacos[i] = 'T';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                        verificarVitoria();
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });

            JButton y = new JButton("Y");
            y.setBounds(325, altura1, 40, 45);
            y.setBorder(null);
            y.setBackground(Color.decode("#FFFFFF"));
            y.setFont(new Font("Roboto", 1, 14));
            jogo.add(y);
            
            y.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    dis = "";
                    if(new String(caracteres).contains("Y")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'Y'){
                                espacos[i] = 'Y';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                        verificarVitoria();
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });

            JButton u = new JButton("U");
            u.setBounds(370, altura1, 40, 45);
            u.setBorder(null);
            u.setBackground(Color.decode("#FFFFFF"));
            u.setFont(new Font("Roboto", 1, 14));
            jogo.add(u);
            
            u.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    dis = "";
                    if(new String(caracteres).contains("U")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'U'){
                                espacos[i] = 'U';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                        verificarVitoria();
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });

            JButton i = new JButton("I");
            i.setBounds(415, altura1, 40, 45);
            i.setBorder(null);
            i.setBackground(Color.decode("#FFFFFF"));
            i.setFont(new Font("Roboto", 1, 14));
            jogo.add(i);
            
            i.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    dis = "";
                    if(new String(caracteres).contains("I")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'I'){
                                espacos[i] = 'I';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                        verificarVitoria();
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });

            JButton o = new JButton("O");
            o.setBounds(460, altura1, 40, 45);
            o.setBorder(null);
            o.setBackground(Color.decode("#FFFFFF"));
            o.setFont(new Font("Roboto", 1, 14));
            jogo.add(o);
            
            o.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    dis = "";
                    if(new String(caracteres).contains("O")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'O'){
                                espacos[i] = 'O';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                        verificarVitoria();
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });

            JButton p = new JButton("P");
            p.setBounds(505, altura1, 60, 45);
            p.setBorder(null);
            p.setBackground(Color.decode("#FFFFFF"));
            p.setFont(new Font("Roboto", 1, 14));
            jogo.add(p);
            
            p.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    dis = "";
                    if(new String(caracteres).contains("P")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'P'){
                                espacos[i] = 'P';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                        verificarVitoria();
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });



            // Parte teclado 2

            JButton a = new JButton("A");
            a.setBounds(100, altura2, 60, 45);
            a.setBorder(null);
            a.setBackground(Color.decode("#FFFFFF"));
            a.setFont(new Font("Roboto", 1, 14));
            jogo.add(a);
            
            a.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    dis = "";
                    if(new String(caracteres).contains("A")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'A'){
                                espacos[i] = 'A';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                        verificarVitoria();
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });

            JButton s = new JButton("S");
            s.setBounds(165, altura2, 40, 45);
            s.setBorder(null);
            s.setBackground(Color.decode("#FFFFFF"));
            s.setFont(new Font("Roboto", 1, 14));
            jogo.add(s);
            
            s.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    dis = "";
                    if(new String(caracteres).contains("S")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'S'){
                                espacos[i] = 'S';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                        verificarVitoria();
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });

            JButton d = new JButton("D");
            d.setBounds(210, altura2, 40, 45);
            d.setBorder(null);
            d.setBackground(Color.decode("#FFFFFF"));
            d.setFont(new Font("Roboto", 1, 14));
            jogo.add(d);
            
            d.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    dis = "";
                    if(new String(caracteres).contains("D")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'D'){
                                espacos[i] = 'D';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                        verificarVitoria();
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });

            JButton f = new JButton("F");
            f.setBounds(255, altura2, 40, 45);
            f.setBorder(null);
            f.setBackground(Color.decode("#FFFFFF"));
            f.setFont(new Font("Roboto", 1, 14));
            jogo.add(f);
            
            f.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    dis = "";
                    if(new String(caracteres).contains("F")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'F'){
                                espacos[i] = 'F';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                        verificarVitoria();
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });

            JButton g = new JButton("G");
            g.setBounds(300, altura2, 40, 45);
            g.setBorder(null);
            g.setBackground(Color.decode("#FFFFFF"));
            g.setFont(new Font("Roboto", 1, 14));
            jogo.add(g);
            
            g.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    dis = "";
                    if(new String(caracteres).contains("G")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'G'){
                                espacos[i] = 'G';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                        verificarVitoria();
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });

            JButton h = new JButton("H");
            h.setBounds(345, altura2, 40, 45);
            h.setBorder(null);
            h.setBackground(Color.decode("#FFFFFF"));
            h.setFont(new Font("Roboto", 1, 14));
            jogo.add(h);
            
            h.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    dis = "";
                    if(new String(caracteres).contains("H")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'H'){
                                espacos[i] = 'H';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                        verificarVitoria();
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });

            JButton j = new JButton("J");
            j.setBounds(390, altura2, 40, 45);
            j.setBorder(null);
            j.setBackground(Color.decode("#FFFFFF"));
            j.setFont(new Font("Roboto", 1, 14));
            jogo.add(j);
            
            j.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    dis = "";
                    if(new String(caracteres).contains("J")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'J'){
                                espacos[i] = 'J';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                        verificarVitoria();
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });

            JButton k = new JButton("K");
            k.setBounds(435, altura2, 40, 45);
            k.setBorder(null);
            k.setBackground(Color.decode("#FFFFFF"));
            k.setFont(new Font("Roboto", 1, 14));
            jogo.add(k);
            
            k.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    dis = "";
                    if(new String(caracteres).contains("K")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'K'){
                                espacos[i] = 'K';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                        verificarVitoria();
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });

            JButton l = new JButton("L");
            l.setBounds(480, altura2, 40, 45);
            l.setBorder(null);
            l.setBackground(Color.decode("#FFFFFF"));
            l.setFont(new Font("Roboto", 1, 14));
            jogo.add(l);
            
            l.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    dis = "";
                    if(new String(caracteres).contains("L")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'L'){
                                espacos[i] = 'L';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                        verificarVitoria();
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });

            JButton cC = new JButton("Ç");
            cC.setBounds(525, altura2, 40, 45);
            cC.setBorder(null);
            cC.setBackground(Color.decode("#FFFFFF"));
            cC.setFont(new Font("Roboto", 1, 14));
            jogo.add(cC);
            
            cC.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    dis = "";
                    if(new String(caracteres).contains("Ç")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'Ç'){
                                espacos[i] = 'Ç';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                        verificarVitoria();
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });



            // Parte teclado 3

            JButton z = new JButton("Z");
            z.setBounds(100, altura3, 80, 45);
            z.setBorder(null);
            z.setBackground(Color.decode("#FFFFFF"));
            z.setFont(new Font("Roboto", 1, 14));
            jogo.add(z);
            
            z.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    dis = "";
                    if(new String(caracteres).contains("Z")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'Z'){
                                espacos[i] = 'Z';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                        verificarVitoria();
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });

            JButton x = new JButton("X");
            x.setBounds(185, altura3, 40, 45);
            x.setBorder(null);
            x.setBackground(Color.decode("#FFFFFF"));
            x.setFont(new Font("Roboto", 1, 14));
            jogo.add(x);
            
            x.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    dis = "";
                    if(new String(caracteres).contains("X")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'X'){
                                espacos[i] = 'X';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                        verificarVitoria();
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });

            JButton c = new JButton("C");
            c.setBounds(230, altura3, 40, 45);
            c.setBorder(null);
            c.setBackground(Color.decode("#FFFFFF"));
            c.setFont(new Font("Roboto", 1, 14));
            jogo.add(c);
            
            c.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    dis = "";
                    if(new String(caracteres).contains("C")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'C'){
                                espacos[i] = 'C';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                        verificarVitoria();
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });

            JButton v = new JButton("V");
            v.setBounds(275, altura3, 40, 45);
            v.setBorder(null);
            v.setBackground(Color.decode("#FFFFFF"));
            v.setFont(new Font("Roboto", 1, 14));
            jogo.add(v);
            
            v.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    dis = "";
                    if(new String(caracteres).contains("V")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'V'){
                                espacos[i] = 'V';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                        verificarVitoria();
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });

            JButton b = new JButton("B");
            b.setBounds(320, altura3, 40, 45);
            b.setBorder(null);
            b.setBackground(Color.decode("#FFFFFF"));
            b.setFont(new Font("Roboto", 1, 14));
            jogo.add(b);
            
            b.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    dis = "";
                    if(new String(caracteres).contains("B")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'B'){
                                espacos[i] = 'B';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                        verificarVitoria();
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });

            JButton n = new JButton("N");
            n.setBounds(365, altura3, 40, 45);
            n.setBorder(null);
            n.setBackground(Color.decode("#FFFFFF"));
            n.setFont(new Font("Roboto", 1, 14));
            jogo.add(n);
            
            n.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    dis = "";
                    if(new String(caracteres).contains("N")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'N'){
                                espacos[i] = 'N';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                        verificarVitoria();
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });

            JButton m = new JButton("M");
            m.setBounds(410, altura3, 40, 45);
            m.setBorder(null);
            m.setBackground(Color.decode("#FFFFFF"));
            m.setFont(new Font("Roboto", 1, 14));
            jogo.add(m);
            
            m.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    dis = "";
                    if(new String(caracteres).contains("M")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == 'M'){
                                espacos[i] = 'M';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                        verificarVitoria();
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });

            JButton hifen = new JButton("-");
            hifen.setBounds(455, altura3, 110, 45);
            hifen.setBorder(null);
            hifen.setBackground(Color.decode("#FFFFFF"));
            hifen.setFont(new Font("Roboto", 1, 14));
            jogo.add(hifen);
            
            hifen.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    dis = "";
                    if(new String(caracteres).contains("-")) {
                        for(int i = 0; i < caracteres.length; i++){
                            if(caracteres[i] == '-'){
                                espacos[i] = '-';
                                dis += espacos[i] + " ";
                            }
                            else {
                                dis += espacos[i] + " ";
                            }
                        }
                        display.setText(dis); 
                        verificarVitoria();
                    } else {
                        derrotas = derrotas + 1;
                        verificarDerrota();
                        System.out.println("Letras incorretas: " + derrotas);
                    }
                }
            });

            jogo.add(painel);
            jogo.setVisible(true);

        } else {

            JOptionPane.showMessageDialog(null, "Não existe nenhum valor na caixa de texto!");

        }

    }

}